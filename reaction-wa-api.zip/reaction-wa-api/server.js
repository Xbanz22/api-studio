const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = 3002;
const BASE_URL = 'https://reaction-whatsapp.edgeone.dev';
const API_KEY = 'C3CENFUP';

// Rate limit store (in-memory)
const rateLimitStore = new Map();
const RATE_LIMIT = 10; // max request per menit
const WINDOW_MS = 60 * 1000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============ RATE LIMIT MIDDLEWARE ============
function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const record = rateLimitStore.get(ip);

  if (!record || now > record.resetAt) {
    rateLimitStore.set(ip, { count: 1, resetAt: now + WINDOW_MS });
    return next();
  }

  if (record.count >= RATE_LIMIT) {
    const wait = Math.ceil((record.resetAt - now) / 1000);
    return res.status(429).json({
      status: false,
      message: `Rate limit tercapai. Coba lagi dalam ${wait} detik.`
    });
  }

  record.count++;
  next();
}

// ============ VALIDATION ============
function validateInput(link, emoji) {
  if (!link || typeof link !== 'string') {
    return 'Link wajib diisi dan harus string.';
  }
  
  // Support: chat.whatsapp.com, whatsapp.com, wa.me
  const validDomains = [
    'https://chat.whatsapp.com/',
    'https://whatsapp.com/',
    'https://www.whatsapp.com/',
    'https://wa.me/',
  ];
  
  const isValid = validDomains.some(domain => link.startsWith(domain));
  if (!isValid) {
    return 'Link harus dari WhatsApp (chat.whatsapp.com, whatsapp.com, atau wa.me)';
  }
  
  if (!emoji || typeof emoji !== 'string') {
    return 'Emoji wajib diisi.';
  }
  if (emoji.length > 10) {
    return 'Emoji terlalu panjang (max 10 karakter).';
  }
  return null;
}

// ============ ENDPOINTS ============

// GET / — form HTML
app.get('/', (req, res) => {
  res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reaction WA API</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, sans-serif;
      background: linear-gradient(135deg, #0a0a1a, #1a0a2e);
      color: #fff;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .container {
      max-width: 500px;
      width: 100%;
      background: rgba(255,255,255,0.05);
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 16px;
      padding: 32px;
    }
    h1 { margin-bottom: 8px; font-size: 24px; }
    p { color: #aaa; margin-bottom: 24px; font-size: 14px; }
    label { display: block; margin-bottom: 8px; font-size: 14px; color: #ccc; }
    input {
      width: 100%;
      padding: 12px 16px;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 8px;
      color: #fff;
      font-size: 14px;
      margin-bottom: 16px;
    }
    input:focus { outline: none; border-color: #7c3aed; }
    button {
      width: 100%;
      padding: 14px;
      background: linear-gradient(135deg, #7c3aed, #a855f7);
      border: none;
      border-radius: 8px;
      color: #fff;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s;
    }
    button:hover { transform: translateY(-2px); }
    button:disabled { opacity: 0.5; cursor: not-allowed; }
    #result {
      margin-top: 24px;
      padding: 16px;
      background: rgba(0,0,0,0.3);
      border-radius: 8px;
      font-family: monospace;
      font-size: 12px;
      white-space: pre-wrap;
      word-break: break-all;
      display: none;
    }
    .success { border-left: 3px solid #22c55e; }
    .error { border-left: 3px solid #ef4444; }
  </style>
</head>
<body>
  <div class="container">
    <h1>🎭 Reaction WA API</h1>
    <p>Kirim reaction ke link WhatsApp</p>

    <label>Link WhatsApp</label>
    <input type="text" id="link" placeholder="https://chat.whatsapp.com/..." />

    <label>Emoji</label>
    <input type="text" id="emoji" placeholder="😀" maxlength="10" />

    <button onclick="submitForm()" id="btn">Kirim Reaction</button>

    <div id="result"></div>
  </div>

  <script>
    async function submitForm() {
      const link = document.getElementById('link').value.trim();
      const emoji = document.getElementById('emoji').value.trim();
      const btn = document.getElementById('btn');
      const result = document.getElementById('result');

      if (!link || !emoji) {
        alert('Link & emoji wajib diisi!');
        return;
      }

      btn.disabled = true;
      btn.textContent = 'Mengirim...';
      result.style.display = 'none';

      try {
        const res = await fetch('/api/react', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ link, emoji })
        });
        const data = await res.json();

        result.style.display = 'block';
        result.className = data.status ? 'success' : 'error';
        result.textContent = JSON.stringify(data, null, 2);
      } catch (err) {
        result.style.display = 'block';
        result.className = 'error';
        result.textContent = 'Error: ' + err.message;
      } finally {
        btn.disabled = false;
        btn.textContent = 'Kirim Reaction';
      }
    }
  </script>
</body>
</html>
  `);
});

// GET /api/health
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// POST /api/react
app.post('/api/react', rateLimit, async (req, res) => {
  const { link, emoji } = req.body;

  console.log(`[${new Date().toISOString()}] POST /api/react — link: ${link}, emoji: ${emoji}`);

  // Validasi
  const error = validateInput(link, emoji);
  if (error) {
    return res.status(400).json({ status: false, message: error });
  }

  try {
    const response = await axios.post(
      `${BASE_URL}/react`,
      { link, emoji },
      {
        timeout: 60000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${API_KEY}`,
          'Origin': BASE_URL,
          'Referer': BASE_URL + '/'
        },
        validateStatus: () => true
      }
    );

    res.status(response.status).json({
      status: response.status === 200,
      httpStatus: response.status,
      data: response.data
    });
  } catch (err) {
    console.error('[ERROR]', err.message);
    res.status(500).json({
      status: false,
      message: err.message
    });
  }
});

// ============ START SERVER ============
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════╗
║  🎭 Reaction WA API                        ║
║  Port: ${PORT}                                ║
║  URL:  http://localhost:${PORT}               ║
╚════════════════════════════════════════════╝
  `);
});
